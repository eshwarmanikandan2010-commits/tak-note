import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { generateNotePDF } from "@/lib/pdf-generator";
import type { Note } from "@shared/schema";
import { format } from "date-fns";
import { FileText, Edit, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface NoteCardProps {
  note: Note;
}

export default function NoteCard({ note }: NoteCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteNoteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/notes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
      toast({
        title: "Success",
        description: "Note deleted successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete note",
        variant: "destructive",
      });
    },
  });

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this note?")) {
      deleteNoteMutation.mutate(note.id);
    }
  };

  const handleExportPDF = () => {
    generateNotePDF(note.title, note.content);
    toast({
      title: "PDF Exported",
      description: `"${note.title}" has been exported as PDF successfully!`,
    });
  };

  const truncatedContent = note.content.length > 150 
    ? note.content.substring(0, 150) + "..." 
    : note.content;

  return (
    <Card className="transition-shadow hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="font-semibold text-gray-900">{note.title}</h3>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExportPDF}
              className="text-gray-400 hover:text-primary"
              data-testid={`button-export-pdf-${note.id}`}
            >
              <FileText className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-400 hover:text-blue-500"
              data-testid={`button-edit-note-${note.id}`}
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              disabled={deleteNoteMutation.isPending}
              className="text-gray-400 hover:text-red-500"
              data-testid={`button-delete-note-${note.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 whitespace-pre-wrap">
          {truncatedContent}
        </p>
        
        <div className="flex items-center justify-between">
          <Badge 
            variant="outline" 
            className={cn(
              "text-xs font-medium",
              `category-${note.category}`
            )}
          >
            {note.category.charAt(0).toUpperCase() + note.category.slice(1)}
          </Badge>
          <span className="text-xs text-gray-500">
            {format(new Date(note.updatedAt), 'MMM dd, h:mm a')}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
