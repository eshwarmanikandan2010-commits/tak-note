import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Reminder } from "@shared/schema";
import { format, isPast, isToday, isTomorrow } from "date-fns";
import { Calendar, Edit, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface ReminderCardProps {
  reminder: Reminder;
}

export default function ReminderCard({ reminder }: ReminderCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateReminderMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Reminder> }) => {
      const response = await apiRequest("PUT", `/api/reminders/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update reminder",
        variant: "destructive",
      });
    },
  });

  const deleteReminderMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/reminders/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      toast({
        title: "Success",
        description: "Reminder deleted successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete reminder",
        variant: "destructive",
      });
    },
  });

  const handleToggleComplete = (checked: boolean) => {
    updateReminderMutation.mutate({
      id: reminder.id,
      updates: { completed: checked },
    });
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this reminder?")) {
      deleteReminderMutation.mutate(reminder.id);
    }
  };

  const formatDate = (date: Date) => {
    if (isToday(date)) return "Today";
    if (isTomorrow(date)) return "Tomorrow";
    return format(date, "MMM dd");
  };

  const isOverdue = !reminder.completed && isPast(new Date(reminder.dueDate));

  return (
    <Card className={cn(
      "transition-shadow hover:shadow-md",
      reminder.completed && "opacity-75",
      isOverdue && "border-red-200 bg-red-50"
    )}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-start">
            <Checkbox
              checked={reminder.completed}
              onCheckedChange={handleToggleComplete}
              className="mt-1 mr-4"
              data-testid={`checkbox-reminder-${reminder.id}`}
            />
            <div className="flex-1">
              <h3 className={cn(
                "font-semibold text-gray-900 mb-2",
                reminder.completed && "line-through"
              )}>
                {reminder.title}
              </h3>
              {reminder.description && (
                <p className="text-gray-600 mb-3">{reminder.description}</p>
              )}
              <div className="flex items-center space-x-4">
                <div className="flex items-center text-sm text-gray-500">
                  <Calendar className="mr-1 h-4 w-4" />
                  {formatDate(new Date(reminder.dueDate))}, {format(new Date(reminder.dueDate), 'h:mm a')}
                </div>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs font-medium",
                    `priority-${reminder.priority}`
                  )}
                >
                  {reminder.priority.charAt(0).toUpperCase() + reminder.priority.slice(1)} Priority
                </Badge>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs font-medium",
                    `category-${reminder.category}`
                  )}
                >
                  {reminder.category.charAt(0).toUpperCase() + reminder.category.slice(1)}
                </Badge>
                {isOverdue && (
                  <Badge variant="destructive" className="text-xs">
                    Overdue
                  </Badge>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm"
              className="text-gray-400 hover:text-blue-500"
              data-testid={`button-edit-reminder-${reminder.id}`}
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              className="text-gray-400 hover:text-red-500"
              onClick={handleDelete}
              disabled={deleteReminderMutation.isPending}
              data-testid={`button-delete-reminder-${reminder.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
