import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { CheckCircle, Home, Bell, StickyNote } from "lucide-react";

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: "dashboard" | "reminders" | "notes") => void;
  stats: {
    totalReminders: number;
    completed: number;
    overdue: number;
    totalNotes: number;
  };
}

export default function Sidebar({ activeTab, onTabChange, stats }: SidebarProps) {
  const progress = stats.totalReminders > 0 ? Math.round((stats.completed / stats.totalReminders) * 100) : 0;
  
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "reminders", label: "Reminders", icon: Bell },
    { id: "notes", label: "Notes", icon: StickyNote },
  ];

  return (
    <div className="w-64 bg-white shadow-sm border-r border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-xl font-bold text-gray-900 flex items-center">
          <CheckCircle className="text-primary h-5 w-5 mr-2" />
          TaskNote
        </h1>
      </div>
      
      <nav className="mt-6">
        <div className="px-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id as any)}
                className={cn(
                  "w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg mb-1 transition-colors",
                  isActive 
                    ? "text-primary bg-primary-50" 
                    : "text-gray-700 hover:text-primary hover:bg-gray-50"
                )}
                data-testid={`nav-${item.id}`}
              >
                <Icon className="mr-3 h-4 w-4" />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>

      <div className="px-6 mt-8">
        <Card className="bg-gradient-to-br from-primary-50 to-blue-50 border-primary-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Today's Progress</span>
              <span className="text-xs text-gray-500" data-testid="text-progress-percentage">{progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300" 
                style={{ width: `${progress}%` }}
                data-testid="progress-bar"
              />
            </div>
            <p className="text-xs text-gray-600 mt-2" data-testid="text-progress-summary">
              {stats.completed} of {stats.totalReminders} tasks completed
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
