import type { Reminder } from "@shared/schema";

export function initializeNotifications() {
  if ('Notification' in window) {
    if (Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }
}

export function showNotification(title: string, body: string, icon?: string) {
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(title, {
      body,
      icon: icon || '/favicon.ico',
      tag: 'reminder',
    });
  }
}

export function scheduleReminderNotification(reminder: Reminder) {
  const now = new Date();
  const dueDate = new Date(reminder.dueDate);
  const timeDiff = dueDate.getTime() - now.getTime();
  
  // Show notification 15 minutes before due date
  const notificationTime = timeDiff - (15 * 60 * 1000);
  
  if (notificationTime > 0 && notificationTime <= 24 * 60 * 60 * 1000) { // Within 24 hours
    setTimeout(() => {
      showNotification(
        'Reminder: ' + reminder.title,
        `Due in 15 minutes: ${reminder.description || reminder.title}`,
      );
    }, notificationTime);
  }
  
  // Show notification at due time
  if (timeDiff > 0 && timeDiff <= 24 * 60 * 60 * 1000) { // Within 24 hours
    setTimeout(() => {
      showNotification(
        'Reminder Due: ' + reminder.title,
        reminder.description || reminder.title,
      );
    }, timeDiff);
  }
}

export function createReminderNotification(reminder: Reminder) {
  // For immediate reminders (within next hour)
  const now = new Date();
  const dueDate = new Date(reminder.dueDate);
  const timeDiff = dueDate.getTime() - now.getTime();
  
  if (timeDiff > 0 && timeDiff <= 60 * 60 * 1000) { // Within 1 hour
    showNotification(
      'New Reminder Created',
      `"${reminder.title}" is due ${timeDiff < 30 * 60 * 1000 ? 'soon' : 'in less than an hour'}!`,
    );
  }
}
