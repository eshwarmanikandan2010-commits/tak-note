import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import ReminderForm from "@/components/reminder-form";
import NoteForm from "@/components/note-form";
import ReminderCard from "@/components/reminder-card";
import NoteCard from "@/components/note-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Plus, CheckCircle, Clock, AlertCircle, StickyNote } from "lucide-react";
import type { Reminder, Note } from "@shared/schema";
import { format, isToday, isTomorrow, isPast } from "date-fns";
import { initializeNotifications, scheduleReminderNotification } from "@/lib/notifications";

type ActiveTab = "dashboard" | "reminders" | "notes";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("dashboard");
  const [searchQuery, setSearchQuery] = useState("");
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [showNoteForm, setShowNoteForm] = useState(false);
  const [reminderFilter, setReminderFilter] = useState("all");
  const [noteFilter, setNoteFilter] = useState("all");

  const { data: reminders = [], isLoading: remindersLoading } = useQuery<Reminder[]>({
    queryKey: ['/api/reminders'],
  });

  const { data: notes = [], isLoading: notesLoading } = useQuery<Note[]>({
    queryKey: ['/api/notes'],
  });

  useEffect(() => {
    initializeNotifications();
  }, []);

  useEffect(() => {
    reminders.forEach(reminder => {
      if (!reminder.completed && new Date(reminder.dueDate) > new Date()) {
        scheduleReminderNotification(reminder);
      }
    });
  }, [reminders]);

  const filteredReminders = reminders.filter(reminder => {
    const matchesSearch = reminder.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reminder.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (reminderFilter === "active") return !reminder.completed && matchesSearch;
    if (reminderFilter === "completed") return reminder.completed && matchesSearch;
    if (reminderFilter === "overdue") return !reminder.completed && isPast(new Date(reminder.dueDate)) && matchesSearch;
    
    return matchesSearch;
  });

  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (noteFilter === "all") return matchesSearch;
    return note.category === noteFilter && matchesSearch;
  });

  const stats = {
    totalReminders: reminders.length,
    completed: reminders.filter(r => r.completed).length,
    overdue: reminders.filter(r => !r.completed && isPast(new Date(r.dueDate))).length,
    totalNotes: notes.length,
  };

  const upcomingReminders = reminders
    .filter(r => !r.completed && new Date(r.dueDate) >= new Date())
    .slice(0, 3);

  const recentNotes = notes.slice(0, 3);

  const getPageTitle = () => {
    switch (activeTab) {
      case "reminders": return "Reminders";
      case "notes": return "Notes";
      default: return "Dashboard";
    }
  };

  const handleCreateNew = () => {
    if (activeTab === "notes") {
      setShowNoteForm(true);
    } else {
      setShowReminderForm(true);
    }
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        stats={stats}
      />

      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">{getPageTitle()}</h2>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search reminders & notes..."
                  className="w-64 pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  data-testid="input-search"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              </div>
              <Button onClick={handleCreateNew} data-testid="button-new">
                <Plus className="mr-2 h-4 w-4" />
                New
              </Button>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-6">
          {activeTab === "dashboard" && (
            <div>
              {/* Stats Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="p-2 bg-primary-50 rounded-lg">
                        <CheckCircle className="text-primary-600 h-5 w-5" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Total Reminders</p>
                        <p className="text-2xl font-bold text-gray-900" data-testid="text-total-reminders">
                          {stats.totalReminders}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="p-2 bg-emerald-100 rounded-lg">
                        <CheckCircle className="text-emerald-600 h-5 w-5" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Completed</p>
                        <p className="text-2xl font-bold text-gray-900" data-testid="text-completed">
                          {stats.completed}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="p-2 bg-amber-100 rounded-lg">
                        <Clock className="text-amber-600 h-5 w-5" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Overdue</p>
                        <p className="text-2xl font-bold text-gray-900" data-testid="text-overdue">
                          {stats.overdue}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <StickyNote className="text-purple-600 h-5 w-5" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Notes</p>
                        <p className="text-2xl font-bold text-gray-900" data-testid="text-total-notes">
                          {stats.totalNotes}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Upcoming Reminders */}
                <Card>
                  <div className="p-6 border-b border-gray-100">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900">Upcoming Reminders</h3>
                      <Button variant="ghost" size="sm" onClick={() => setActiveTab("reminders")} data-testid="link-view-all-reminders">
                        View All
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    {remindersLoading ? (
                      <div className="text-center text-gray-500">Loading reminders...</div>
                    ) : upcomingReminders.length === 0 ? (
                      <div className="text-center text-gray-500">No upcoming reminders</div>
                    ) : (
                      <div className="space-y-4">
                        {upcomingReminders.map((reminder) => (
                          <div key={reminder.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                            <div className="flex items-center">
                              <div className={`w-3 h-3 rounded-full mr-3 ${
                                reminder.priority === 'high' ? 'bg-red-500' :
                                reminder.priority === 'medium' ? 'bg-amber-500' : 'bg-green-500'
                              }`} />
                              <div>
                                <p className="font-medium text-gray-900">{reminder.title}</p>
                                <p className="text-sm text-gray-500">
                                  {isToday(new Date(reminder.dueDate)) ? 'Today' :
                                   isTomorrow(new Date(reminder.dueDate)) ? 'Tomorrow' :
                                   format(new Date(reminder.dueDate), 'MMM dd')}, {format(new Date(reminder.dueDate), 'h:mm a')}
                                </p>
                              </div>
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium priority-${reminder.priority}`}>
                              {reminder.priority.charAt(0).toUpperCase() + reminder.priority.slice(1)}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Recent Notes */}
                <Card>
                  <div className="p-6 border-b border-gray-100">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900">Recent Notes</h3>
                      <Button variant="ghost" size="sm" onClick={() => setActiveTab("notes")} data-testid="link-view-all-notes">
                        View All
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    {notesLoading ? (
                      <div className="text-center text-gray-500">Loading notes...</div>
                    ) : recentNotes.length === 0 ? (
                      <div className="text-center text-gray-500">No notes yet</div>
                    ) : (
                      <div className="space-y-4">
                        {recentNotes.map((note) => (
                          <div key={note.id} className="py-3 border-b border-gray-100 last:border-b-0">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900 mb-1">{note.title}</h4>
                                <p className="text-sm text-gray-600 line-clamp-2">
                                  {note.content.substring(0, 100)}...
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center justify-between mt-2">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium category-${note.category}`}>
                                {note.category.charAt(0).toUpperCase() + note.category.slice(1)}
                              </span>
                              <span className="text-xs text-gray-500">
                                {format(new Date(note.updatedAt), 'MMM dd, h:mm a')}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "reminders" && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="flex space-x-2">
                  <Button 
                    variant={reminderFilter === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setReminderFilter("all")}
                    data-testid="button-filter-all-reminders"
                  >
                    All
                  </Button>
                  <Button 
                    variant={reminderFilter === "active" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setReminderFilter("active")}
                    data-testid="button-filter-active-reminders"
                  >
                    Active
                  </Button>
                  <Button 
                    variant={reminderFilter === "completed" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setReminderFilter("completed")}
                    data-testid="button-filter-completed-reminders"
                  >
                    Completed
                  </Button>
                  <Button 
                    variant={reminderFilter === "overdue" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setReminderFilter("overdue")}
                    data-testid="button-filter-overdue-reminders"
                  >
                    Overdue
                  </Button>
                </div>
                <Button onClick={() => setShowReminderForm(true)} data-testid="button-add-reminder">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Reminder
                </Button>
              </div>

              <div className="space-y-4">
                {remindersLoading ? (
                  <div className="text-center text-gray-500">Loading reminders...</div>
                ) : filteredReminders.length === 0 ? (
                  <div className="text-center text-gray-500">No reminders found</div>
                ) : (
                  filteredReminders.map((reminder) => (
                    <ReminderCard key={reminder.id} reminder={reminder} />
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === "notes" && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="flex space-x-2">
                  <Button 
                    variant={noteFilter === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setNoteFilter("all")}
                    data-testid="button-filter-all-notes"
                  >
                    All Notes
                  </Button>
                  <Button 
                    variant={noteFilter === "work" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setNoteFilter("work")}
                    data-testid="button-filter-work-notes"
                  >
                    Work
                  </Button>
                  <Button 
                    variant={noteFilter === "personal" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setNoteFilter("personal")}
                    data-testid="button-filter-personal-notes"
                  >
                    Personal
                  </Button>
                  <Button 
                    variant={noteFilter === "meeting" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setNoteFilter("meeting")}
                    data-testid="button-filter-meeting-notes"
                  >
                    Meeting
                  </Button>
                </div>
                <Button onClick={() => setShowNoteForm(true)} data-testid="button-new-note">
                  <Plus className="mr-2 h-4 w-4" />
                  New Note
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {notesLoading ? (
                  <div className="col-span-full text-center text-gray-500">Loading notes...</div>
                ) : filteredNotes.length === 0 ? (
                  <div className="col-span-full text-center text-gray-500">No notes found</div>
                ) : (
                  filteredNotes.map((note) => (
                    <NoteCard key={note.id} note={note} />
                  ))
                )}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Modals */}
      <Dialog open={showReminderForm} onOpenChange={setShowReminderForm}>
        <DialogContent className="sm:max-w-[500px]">
          <ReminderForm onClose={() => setShowReminderForm(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={showNoteForm} onOpenChange={setShowNoteForm}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-hidden">
          <NoteForm onClose={() => setShowNoteForm(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
