#!/bin/bash

# TaskNote App Deployment Script

set -e  # Exit on any error

echo "🚀 Starting TaskNote App deployment..."

# Check if required commands exist
command -v node >/dev/null 2>&1 || { echo "❌ Node.js is required but not installed. Aborting." >&2; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "❌ npm is required but not installed. Aborting." >&2; exit 1; }

# Install dependencies
echo "📦 Installing dependencies..."
npm ci

# Type check
echo "🔍 Running type check..."
npm run check

# Build the application
echo "🏗️  Building application..."
npm run build

# Check if build was successful
if [ ! -d "dist" ]; then
    echo "❌ Build failed - dist directory not found"
    exit 1
fi

if [ ! -d "client/dist" ]; then
    echo "❌ Client build failed - client/dist directory not found"
    exit 1
fi

echo "✅ Build completed successfully!"

# Database setup (if using PostgreSQL)
if [ ! -z "$DATABASE_URL" ]; then
    echo "🗄️  Setting up database..."
    npm run db:push
fi

echo "🎉 Deployment completed successfully!"
echo ""
echo "📋 Next steps:"
echo "1. Set your environment variables (see .env.example)"
echo "2. Run 'npm start' to start the production server"
echo "3. Your app will be available at http://localhost:5000"

# Make the script executable
chmod +x deploy.sh