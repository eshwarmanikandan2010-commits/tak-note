# Overview

TaskNote is a full-stack web application built for managing reminders and notes. It features a React frontend with TypeScript, Express.js backend, and uses Drizzle ORM for database operations with PostgreSQL. The application provides a clean dashboard interface where users can create, manage, and organize their personal reminders and notes with features like priority levels, categories, search functionality, and PDF export capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React with TypeScript**: Single-page application using Vite as the build tool and development server
- **Component Library**: shadcn/ui components built on top of Radix UI primitives for consistent, accessible UI elements
- **Styling**: Tailwind CSS with CSS custom properties for theming and responsive design
- **State Management**: TanStack React Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **File Structure**: Organized with clear separation between pages, components, and utilities

## Backend Architecture
- **Express.js Server**: RESTful API with middleware for request logging and error handling
- **TypeScript**: Full type safety across the entire backend
- **Development Setup**: Custom Vite integration for seamless development experience in development mode
- **API Structure**: Clean REST endpoints for reminders (`/api/reminders`) and notes (`/api/notes`) with full CRUD operations
- **Error Handling**: Centralized error handling with proper HTTP status codes and JSON responses

## Data Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Two main entities - reminders and notes with proper relationships and constraints
- **Database Features**: UUID primary keys, timestamps, enums for priority levels, and proper indexing
- **Development Storage**: In-memory storage class for development/testing purposes
- **Migrations**: Drizzle Kit for database schema migrations and management

## Authentication & Authorization
- **Current State**: No authentication system implemented - application is open access
- **Session Management**: Basic session infrastructure in place with connect-pg-simple for future implementation

## External Dependencies
- **Neon Database**: Serverless PostgreSQL database provider for production hosting
- **PDF Generation**: jsPDF for client-side PDF export of notes and reminders
- **Notifications API**: Browser Notifications API for reminder alerts and scheduling
- **UI Components**: Comprehensive Radix UI ecosystem for accessible, customizable components
- **Development Tools**: 
  - Replit-specific plugins for runtime error handling and development environment integration
  - ESBuild for production bundling
  - PostCSS with Autoprefixer for CSS processing

## Key Features
- **Reminder Management**: Create, update, delete reminders with due dates, priorities, and categories
- **Note Management**: Full-featured note-taking with categories and content management
- **Search & Filter**: Real-time search across titles and content with category-based filtering
- **Notifications**: Browser-based notification system for reminder alerts
- **PDF Export**: Generate PDF documents for notes and reminder lists
- **Responsive Design**: Mobile-friendly interface with proper touch interactions
- **Real-time Updates**: Optimistic updates and automatic cache invalidation for smooth UX