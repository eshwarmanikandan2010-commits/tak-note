import jsPDF from 'jspdf';

export function generateNotePDF(title: string, content: string) {
  const doc = new jsPDF();
  
  // Set title
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text(title, 20, 30);
  
  // Add creation date
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Created: ${new Date().toLocaleDateString()}`, 20, 45);
  
  // Add content
  doc.setFontSize(12);
  const lines = doc.splitTextToSize(content, 170);
  doc.text(lines, 20, 60);
  
  // Download the PDF
  doc.save(`${title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.pdf`);
}

export function generateRemindersPDF(reminders: any[]) {
  const doc = new jsPDF();
  
  // Set title
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('My Reminders', 20, 30);
  
  // Add creation date
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 45);
  
  let yPosition = 60;
  
  reminders.forEach((reminder, index) => {
    // Check if we need a new page
    if (yPosition > 250) {
      doc.addPage();
      yPosition = 30;
    }
    
    // Reminder title
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(`${index + 1}. ${reminder.title}`, 20, yPosition);
    yPosition += 10;
    
    // Due date and priority
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Due: ${new Date(reminder.dueDate).toLocaleString()} | Priority: ${reminder.priority}`, 20, yPosition);
    yPosition += 8;
    
    // Description
    if (reminder.description) {
      doc.setFontSize(11);
      const lines = doc.splitTextToSize(reminder.description, 170);
      doc.text(lines, 20, yPosition);
      yPosition += lines.length * 5 + 5;
    }
    
    yPosition += 10; // Space between reminders
  });
  
  // Download the PDF
  doc.save('reminders.pdf');
}
